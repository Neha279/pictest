
Steps to setup : 

1. Node js install
   cd to project folder
2. Install Express generator
   > npm install -g express-generator

3.Create Express project
   > express pictest

4. Edit dependencies - edit pacakage json and run
   > npm install

5. Start node 
   note: mkdir data
   npm start
   
browser open -> http://localhost:3000/








   